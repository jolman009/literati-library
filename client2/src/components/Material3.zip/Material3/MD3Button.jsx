import React, { memo, forwardRef } from 'react';
import './MD3Button.css';

const MD3Button = memo(forwardRef(({
  variant = 'filled',
  size = 'medium',
  icon,
  trailingIcon,
  disabled = false,
  loading = false,
  children,
  className = '',
  ...props
}, ref) => {
  const classes = [
    'md3-button',
    `md3-button--${variant}`,
    `md3-button--${size}`,
    disabled && 'md3-button--disabled',
    loading && 'md3-button--loading',
    className
  ].filter(Boolean).join(' ');

  return (
    <button
      ref={ref}
      className={classes}
      disabled={disabled || loading}
      {...props}
    >
      <span className="md3-button__focus-ring" />
      <span className="md3-button__ripple" />
      
      {loading && (
        <span className="md3-button__loading">
          <svg className="md3-button__spinner" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
          </svg>
        </span>
      )}
      
      {icon && !loading && (
        <span className="md3-button__icon md3-button__icon--leading">
          {icon}
        </span>
      )}
      
      <span className="md3-button__label">{children}</span>
      
      {trailingIcon && !loading && (
        <span className="md3-button__icon md3-button__icon--trailing">
          {trailingIcon}
        </span>
      )}
    </button>
  );
}));

MD3Button.displayName = 'MD3Button';
