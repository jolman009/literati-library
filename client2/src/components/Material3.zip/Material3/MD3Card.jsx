// src/components/Material3/MD3Card.jsx
import React, { memo, forwardRef } from 'react';
import './MD3Card.css';

const MD3Card = memo(forwardRef(({
  variant = 'elevated',
  interactive = false,
  disabled = false,
  children,
  className = '',
  onClick,
  ...props
}, ref) => {
  // Remove custom props before passing to DOM
  const {
    interactive: _interactive,
    variant: _variant,
    disabled: _disabled,
    ...domProps
  } = props;

  const classes = [
    'md3-card',
    `md3-card--${variant}`,
    interactive && 'md3-card--interactive',
    disabled && 'md3-card--disabled',
    className
  ].filter(Boolean).join(' ');

  const Component = interactive ? 'button' : 'div';

  return (
    <Component
      ref={ref}
      className={classes}
      disabled={Component === 'button' ? disabled : undefined}
      onClick={interactive && !disabled ? onClick : undefined}
      {...domProps}
    >
      {interactive && <span className="md3-card__ripple" />}
      <div className="md3-card__content">
        {children}
      </div>
    </Component>
  );
}));

MD3Card.displayName = 'MD3Card';

// Export both default and named
export default MD3Card;
export { MD3Card };
