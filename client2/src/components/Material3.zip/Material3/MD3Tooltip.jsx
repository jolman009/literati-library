// src/components/Material3/MD3Tooltip.jsx
import React, { memo, useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import './MD3Tooltip.css';

const MD3Tooltip = memo(({
  title,
  children,
  placement = 'top',
  delay = 500,
  hideDelay = 0,
  variant = 'plain',
  disabled = false,
  offset = 8,
  className = '',
  ...props
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  
  const childRef = useRef();
  const tooltipRef = useRef();
  const showTimeoutRef = useRef();
  const hideTimeoutRef = useRef();

  // Calculate tooltip position
  const calculatePosition = useCallback(() => {
    if (!childRef.current || !tooltipRef.current) return;

    const childRect = childRef.current.getBoundingClientRect();
    const tooltipRect = tooltipRef.current.getBoundingClientRect();
    const viewport = {
      width: window.innerWidth,
      height: window.innerHeight
    };

    let top, left;

    // Calculate base position
    switch (placement) {
      case 'top':
        top = childRect.top - tooltipRect.height - offset;
        left = childRect.left + (childRect.width - tooltipRect.width) / 2;
        break;
      case 'bottom':
        top = childRect.bottom + offset;
        left = childRect.left + (childRect.width - tooltipRect.width) / 2;
        break;
      case 'left':
        top = childRect.top + (childRect.height - tooltipRect.height) / 2;
        left = childRect.left - tooltipRect.width - offset;
        break;
      case 'right':
        top = childRect.top + (childRect.height - tooltipRect.height) / 2;
        left = childRect.right + offset;
        break;
      default:
        top = childRect.top - tooltipRect.height - offset;
        left = childRect.left + (childRect.width - tooltipRect.width) / 2;
    }

    // Viewport boundary adjustments
    if (left < 8) {
      left = 8;
    } else if (left + tooltipRect.width > viewport.width - 8) {
      left = viewport.width - tooltipRect.width - 8;
    }

    if (top < 8) {
      top = childRect.bottom + offset; // Flip to bottom
    } else if (top + tooltipRect.height > viewport.height - 8) {
      top = childRect.top - tooltipRect.height - offset; // Flip to top
    }

    setPosition({ top, left });
  }, [placement, offset]);

  // Show tooltip
  const handleShow = useCallback(() => {
    if (disabled) return;
    
    clearTimeout(hideTimeoutRef.current);
    showTimeoutRef.current = setTimeout(() => {
      setIsVisible(true);
      setIsAnimating(true);
      setTimeout(() => {
        calculatePosition();
        setIsAnimating(false);
      }, 50);
    }, delay);
  }, [disabled, delay, calculatePosition]);

  // Hide tooltip
  const handleHide = useCallback(() => {
    clearTimeout(showTimeoutRef.current);
    hideTimeoutRef.current = setTimeout(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setIsVisible(false);
        setIsAnimating(false);
      }, 200);
    }, hideDelay);
  }, [hideDelay]);

  // Event handlers
  const handleMouseEnter = () => handleShow();
  const handleMouseLeave = () => handleHide();
  const handleFocus = () => handleShow();
  const handleBlur = () => handleHide();

  // Cleanup timeouts
  useEffect(() => {
    return () => {
      clearTimeout(showTimeoutRef.current);
      clearTimeout(hideTimeoutRef.current);
    };
  }, []);

  // Recalculate position on resize
  useEffect(() => {
    if (!isVisible) return;

    const handleResize = () => calculatePosition();
    window.addEventListener('resize', handleResize);
    window.addEventListener('scroll', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleResize);
    };
  }, [isVisible, calculatePosition]);

  // Clone child with event handlers
  const childElement = React.cloneElement(children, {
    ref: childRef,
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave,
    onFocus: handleFocus,
    onBlur: handleBlur,
    'aria-describedby': isVisible ? 'md3-tooltip' : undefined
  });

  const tooltipClasses = [
    'md3-tooltip',
    `md3-tooltip--${variant}`,
    `md3-tooltip--${placement}`,
    isAnimating && (isVisible ? 'md3-tooltip--entering' : 'md3-tooltip--exiting'),
    className
  ].filter(Boolean).join(' ');

  const tooltipContent = isVisible ? (
    <div
      ref={tooltipRef}
      className={tooltipClasses}
      style={{
        top: position.top,
        left: position.left
      }}
      role="tooltip"
      id="md3-tooltip"
      {...props}
    >
      <div className="md3-tooltip__content">
        {title}
      </div>
    </div>
  ) : null;

  return (
    <>
      {childElement}
      {tooltipContent && createPortal(tooltipContent, document.body)}
    </>
  );
});

MD3Tooltip.displayName = 'MD3Tooltip';

// Rich Tooltip with more content
export const MD3RichTooltip = memo(({
  title,
  description,
  actions,
  children,
  ...props
}) => {
  return (
    <MD3Tooltip
      variant="rich"
      title={
        <div className="md3-rich-tooltip__content">
          {title && (
            <div className="md3-rich-tooltip__title">
              {title}
            </div>
          )}
          {description && (
            <div className="md3-rich-tooltip__description">
              {description}
            </div>
          )}
          {actions && (
            <div className="md3-rich-tooltip__actions">
              {actions}
            </div>
          )}
        </div>
      }
      {...props}
    >
      {children}
    </MD3Tooltip>
  );
});

MD3RichTooltip.displayName = 'MD3RichTooltip';

// Book-specific tooltip variants
export const MD3BookTooltip = memo(({
  book,
  children,
  ...props
}) => {
  return (
    <MD3RichTooltip
      title={book.title}
      description={
        <div className="book-tooltip-details">
          <p><strong>Author:</strong> {book.author}</p>
          <p><strong>Progress:</strong> {book.progress}% complete</p>
          {book.rating > 0 && (
            <p><strong>Rating:</strong> {'★'.repeat(book.rating)}{'☆'.repeat(5 - book.rating)}</p>
          )}
        </div>
      }
      placement="right"
      {...props}
    >
      {children}
    </MD3RichTooltip>
  );
});

MD3BookTooltip.displayName = 'MD3BookTooltip';

export default MD3Tooltip;