// src/components/Material3/MD3Progress.jsx
import React, { memo } from 'react';
import './MD3Progress.css';

// Linear Progress Component
export const MD3LinearProgress = memo(({
  value,
  max = 100,
  variant = 'determinate',
  size = 'medium',
  label,
  showValue = false,
  className = '',
  ...props
}) => {
  const percentage = variant === 'determinate' ? Math.min(Math.max((value / max) * 100, 0), 100) : 0;
  
  const classes = [
    'md3-linear-progress',
    `md3-linear-progress--${variant}`,
    `md3-linear-progress--${size}`,
    className
  ].filter(Boolean).join(' ');

  return (
    <div className="md3-linear-progress-container">
      {label && (
        <div className="md3-linear-progress__label-container">
          <span className="md3-linear-progress__label">{label}</span>
          {showValue && variant === 'determinate' && (
            <span className="md3-linear-progress__value">
              {Math.round(percentage)}%
            </span>
          )}
        </div>
      )}
      
      <div 
        className={classes}
        role="progressbar"
        aria-valuenow={variant === 'determinate' ? value : undefined}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-label={label}
        {...props}
      >
        <div className="md3-linear-progress__track" />
        <div 
          className="md3-linear-progress__indicator"
          style={variant === 'determinate' ? { transform: `scaleX(${percentage / 100})` } : undefined}
        />
        {variant === 'indeterminate' && (
          <div className="md3-linear-progress__indicator md3-linear-progress__indicator--secondary" />
        )}
      </div>
    </div>
  );
});

MD3LinearProgress.displayName = 'MD3LinearProgress';

// Circular Progress Component
export const MD3CircularProgress = memo(({
  value,
  max = 100,
  variant = 'determinate',
  size = 'medium',
  thickness = 4,
  label,
  showValue = false,
  className = '',
  ...props
}) => {
  const percentage = variant === 'determinate' ? Math.min(Math.max((value / max) * 100, 0), 100) : 0;
  
  const sizeMap = {
    small: 24,
    medium: 48,
    large: 64
  };
  
  const actualSize = typeof size === 'number' ? size : sizeMap[size];
  const radius = (actualSize - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = circumference;
  const strokeDashoffset = variant === 'determinate' 
    ? circumference - (percentage / 100) * circumference 
    : circumference * 0.75;

  const classes = [
    'md3-circular-progress',
    `md3-circular-progress--${variant}`,
    `md3-circular-progress--${typeof size === 'string' ? size : 'custom'}`,
    className
  ].filter(Boolean).join(' ');

  return (
    <div className="md3-circular-progress-container">
      <div 
        className={classes}
        style={{ width: actualSize, height: actualSize }}
        role="progressbar"
        aria-valuenow={variant === 'determinate' ? value : undefined}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-label={label}
        {...props}
      >
        <svg
          className="md3-circular-progress__svg"
          width={actualSize}
          height={actualSize}
          viewBox={`0 0 ${actualSize} ${actualSize}`}
        >
          {/* Track Circle */}
          <circle
            className="md3-circular-progress__track"
            cx={actualSize / 2}
            cy={actualSize / 2}
            r={radius}
            strokeWidth={thickness}
          />
          
          {/* Progress Circle */}
          <circle
            className="md3-circular-progress__indicator"
            cx={actualSize / 2}
            cy={actualSize / 2}
            r={radius}
            strokeWidth={thickness}
            strokeDasharray={strokeDasharray}
            strokeDashoffset={strokeDashoffset}
            transform={`rotate(-90 ${actualSize / 2} ${actualSize / 2})`}
          />
        </svg>
        
        {/* Center Content */}
        {showValue && variant === 'determinate' && (
          <div className="md3-circular-progress__value">
            {Math.round(percentage)}%
          </div>
        )}
        
        {label && !showValue && (
          <div className="md3-circular-progress__label">
            {label}
          </div>
        )}
      </div>
    </div>
  );
});

MD3CircularProgress.displayName = 'MD3CircularProgress';

// Reading Progress Component (specialized for book applications)
export const MD3ReadingProgress = memo(({
  currentPage,
  totalPages,
  timeRemaining,
  showDetails = true,
  className = '',
  ...props
}) => {
  const percentage = totalPages > 0 ? (currentPage / totalPages) * 100 : 0;
  
  const formatTime = (minutes) => {
    if (minutes < 60) return `${Math.round(minutes)}m`;
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}h ${mins}m`;
  };

  return (
    <div className={`md3-reading-progress ${className}`}>
      <MD3LinearProgress
        value={currentPage}
        max={totalPages}
        variant="determinate"
        size="small"
        {...props}
      />
      
      {showDetails && (
        <div className="md3-reading-progress__details">
          <span className="md3-reading-progress__pages">
            {currentPage} of {totalPages} pages
          </span>
          {timeRemaining && (
            <span className="md3-reading-progress__time">
              {formatTime(timeRemaining)} left
            </span>
          )}
        </div>
      )}
    </div>
  );
});

MD3ReadingProgress.displayName = 'MD3ReadingProgress';

// Loading Progress Component (for file uploads, etc.)
export const MD3LoadingProgress = memo(({
  variant = 'circular',
  size = 'medium',
  label = 'Loading...',
  overlay = false,
  className = '',
  ...props
}) => {
  const containerClasses = [
    'md3-loading-progress',
    overlay && 'md3-loading-progress--overlay',
    className
  ].filter(Boolean).join(' ');

  const ProgressComponent = variant === 'circular' ? MD3CircularProgress : MD3LinearProgress;

  return (
    <div className={containerClasses}>
      <div className="md3-loading-progress__content">
        <ProgressComponent
          variant="indeterminate"
          size={size}
          {...props}
        />
        {label && (
          <span className="md3-loading-progress__label">
            {label}
          </span>
        )}
      </div>
    </div>
  );
});

MD3LoadingProgress.displayName = 'MD3LoadingProgress';