// src/components/Material3/index.jsx - CONSOLIDATED VERSION
// Replace your existing src/components/Material3/index.jsx with this

import React, { createContext, useContext, useState, useCallback } from 'react';
import MD3Snackbar from './MD3Snackbar';

// ===============================================
// THEME PROVIDER
// ===============================================

export {
  MD3NavigationRail,
  MD3NavigationBar,
  MD3NavigationDrawer,
  MD3BookLibraryNavigation,
  MD3NavigationLayout,
  useResponsiveNavigation,
} from './MD3Navigation.jsx';

const Material3ThemeContext = createContext();

export const Material3ThemeProvider = ({ children, defaultTheme = 'auto' }) => {
  const [theme, setTheme] = useState(defaultTheme);

  const toggleTheme = useCallback(() => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  }, []);

  const setThemeMode = useCallback((mode) => {
    setTheme(mode);
  }, []);

  const value = {
    theme,
    toggleTheme,
    setThemeMode,
    isDark: theme === 'dark'
  };

  return (
    <Material3ThemeContext.Provider value={value}>
      <div className={`md3-theme ${theme === 'dark' ? 'md3-theme--dark' : 'md3-theme--light'}`}>
        {children}
      </div>
    </Material3ThemeContext.Provider>
  );
};

export const useMaterial3Theme = () => {
  const context = useContext(Material3ThemeContext);
  if (!context) {
    throw new Error('useMaterial3Theme must be used within a Material3ThemeProvider');
  }
  return context;
};

// ===============================================
// SNACKBAR PROVIDER - CONSOLIDATED VERSION
// ===============================================

const SnackbarContext = createContext();

export const MD3SnackbarProvider = ({ children }) => {
  const [snackbars, setSnackbars] = useState([]);

  const showSnackbar = useCallback(({ message, variant = 'default', duration = 4000, action }) => {
    const id = Date.now() + Math.random();
    const snackbar = { 
      id, 
      message: message || 'Action completed', 
      variant: variant || 'info', 
      duration, 
      action,
      open: true
    };
    
    setSnackbars(prev => [...prev, snackbar]);
    
    if (duration > 0) {
      setTimeout(() => {
        setSnackbars(prev => prev.filter(s => s.id !== id));
      }, duration);
    }
    
    return id;
  }, []);

  const hideSnackbar = useCallback((id) => {
    setSnackbars(prev => prev.filter(s => s.id !== id));
  }, []);

  const hideAll = useCallback(() => {
    setSnackbars([]);
  }, []);

  const value = {
    showSnackbar,
    hideSnackbar,
    hideAll
  };

  return (
    <SnackbarContext.Provider value={value}>
      {children}
      {/* Render snackbars at the bottom of screen */}
      <div className="fixed bottom-4 left-4 right-4 z-50 flex flex-col gap-2 max-w-sm mx-auto md:left-auto md:right-4 md:max-w-md">
        {snackbars.map(snackbar => (
          <MD3Snackbar
            key={snackbar.id}
            message={snackbar.message}
            variant={snackbar.variant}
            action={snackbar.action}
            open={snackbar.open}
            onClose={() => hideSnackbar(snackbar.id)}
          />
        ))}
      </div>
    </SnackbarContext.Provider>
  );
};

export const useSnackbar = () => {
  const context = useContext(SnackbarContext);
  if (!context) {
    throw new Error('useSnackbar must be used within a MD3SnackbarProvider');
  }
  return context;
};

// ===============================================
// BASIC COMPONENTS (inline definitions)
// ===============================================

// Button Component
export const MD3Button = React.forwardRef(({
  variant = 'filled',
  size = 'medium',
  icon,
  trailingIcon,
  disabled = false,
  loading = false,
  children,
  className = '',
  style = {},
  ...props
}, ref) => {
  const baseStyle = {
    padding: size === 'small' ? '8px 16px' : size === 'large' ? '16px 32px' : '12px 24px',
    borderRadius: '24px',
    border: variant === 'outlined' ? '1px solid #79747e' : 'none',
    background: variant === 'filled' ? '#6750a4' : 
               variant === 'outlined' ? 'transparent' : 
               '#e7e0ec',
    color: variant === 'filled' ? '#ffffff' : '#6750a4',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'all 0.2s ease',
    opacity: disabled ? 0.6 : 1,
    ...style
  };

  return (
    <button
      ref={ref}
      style={baseStyle}
      className={className}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <div style={{ 
          width: '16px', 
          height: '16px', 
          border: '2px solid currentColor', 
          borderTopColor: 'transparent', 
          borderRadius: '50%', 
          animation: 'spin 1s linear infinite' 
        }} />
      ) : icon}
      {children}
      {trailingIcon}
    </button>
  );
});

MD3Button.displayName = 'MD3Button';

// Card Component
export const MD3Card = React.forwardRef(({
  variant = 'elevated',
  children,
  className = '',
  style = {},
  ...props
}, ref) => {
  const cardStyle = {
    borderRadius: '12px',
    padding: '16px',
    backgroundColor: '#ffffff',
    boxShadow: variant === 'elevated' ? '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)' :
               variant === 'outlined' ? 'none' : '0 1px 2px rgba(0,0,0,0.1)',
    border: variant === 'outlined' ? '1px solid #e0e0e0' : 'none',
    ...style
  };

  return (
    <div
      ref={ref}
      style={cardStyle}
      className={`md3-card ${className}`}
      {...props}
    >
      {children}
    </div>
  );
});

MD3Card.displayName = 'MD3Card';

// Chip Component
export const MD3Chip = React.forwardRef(({
  label,
  size = 'medium',
  variant = 'filled',
  icon,
  onDelete,
  disabled = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const chipStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: size === 'small' ? '4px 8px' : '6px 12px',
    borderRadius: '16px',
    fontSize: size === 'small' ? '12px' : '14px',
    fontWeight: '500',
    border: variant === 'outlined' ? '1px solid #79747e' : 'none',
    backgroundColor: variant === 'filled' ? '#e7e0ec' : 'transparent',
    color: '#1c1b1f',
    cursor: disabled ? 'not-allowed' : 'default',
    opacity: disabled ? 0.6 : 1,
    transition: 'all 0.2s ease',
    ...style
  };

  return (
    <div
      ref={ref}
      style={chipStyle}
      className={`md3-chip ${className}`}
      {...props}
    >
      {icon && <span style={{ fontSize: size === 'small' ? '14px' : '16px' }}>{icon}</span>}
      <span>{label}</span>
      {onDelete && (
        <button
          onClick={onDelete}
          disabled={disabled}
          style={{
            background: 'none',
            border: 'none',
            cursor: disabled ? 'not-allowed' : 'pointer',
            padding: '2px',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '12px',
            opacity: 0.7,
            transition: 'opacity 0.2s ease'
          }}
          onMouseEnter={(e) => e.target.style.opacity = '1'}
          onMouseLeave={(e) => e.target.style.opacity = '0.7'}
        >
          ✕
        </button>
      )}
    </div>
  );
});

MD3Chip.displayName = 'MD3Chip';

// TextField Component
export const MD3TextField = React.forwardRef(({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  multiline = false,
  rows = 1,
  required = false,
  disabled = false,
  leadingIcon,
  trailingIcon,
  className = '',
  style = {},
  ...props
}, ref) => {
  const textFieldStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
    ...style
  };

  const inputStyle = {
    padding: '12px 16px',
    borderRadius: '8px',
    border: '1px solid #79747e',
    fontSize: '14px',
    backgroundColor: '#ffffff',
    color: '#1c1b1f',
    outline: 'none',
    transition: 'border-color 0.2s ease',
    resize: multiline ? 'vertical' : 'none',
    minHeight: multiline ? `${rows * 1.5}em` : 'auto'
  };

  const InputComponent = multiline ? 'textarea' : 'input';

  return (
    <div style={textFieldStyle} className={`md3-textfield ${className}`}>
      {label && (
        <label style={{ fontSize: '12px', fontWeight: '500', color: '#49454f' }}>
          {label} {required && <span style={{ color: '#ba1a1a' }}>*</span>}
        </label>
      )}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        {leadingIcon && (
          <span style={{ position: 'absolute', left: '12px', fontSize: '16px', color: '#49454f' }}>
            {leadingIcon}
          </span>
        )}
        <InputComponent
          ref={ref}
          type={multiline ? undefined : type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          rows={multiline ? rows : undefined}
          style={{
            ...inputStyle,
            paddingLeft: leadingIcon ? '40px' : '16px',
            paddingRight: trailingIcon ? '40px' : '16px'
          }}
          {...props}
        />
        {trailingIcon && (
          <span style={{ position: 'absolute', right: '12px', fontSize: '16px', color: '#49454f' }}>
            {trailingIcon}
          </span>
        )}
      </div>
    </div>
  );
});

MD3TextField.displayName = 'MD3TextField';

// Dialog Component
export const MD3Dialog = React.forwardRef(({
  open = false,
  onClose,
  title,
  children,
  maxWidth = 'md',
  className = '',
  style = {},
  ...props
}, ref) => {
  if (!open) return null;

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    padding: '16px'
  };

  const dialogStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '16px',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.24)',
    maxWidth: maxWidth === 'sm' ? '400px' : maxWidth === 'lg' ? '800px' : '600px',
    width: '100%',
    maxHeight: '90vh',
    overflow: 'auto',
    ...style
  };

  return (
    <div style={overlayStyle} onClick={onClose}>
      <div
        ref={ref}
        style={dialogStyle}
        className={`md3-dialog ${className}`}
        onClick={(e) => e.stopPropagation()}
        {...props}
      >
        {title && (
          <div style={{ padding: '20px 20px 0', borderBottom: '1px solid #e7e0ec' }}>
            <h2 style={{ margin: '0 0 16px 0', fontSize: '1.25rem', fontWeight: '600', color: '#1c1b1f' }}>
              {title}
            </h2>
          </div>
        )}
        {children}
      </div>
    </div>
  );
});

MD3Dialog.displayName = 'MD3Dialog';

// Surface Component
export const MD3Surface = React.forwardRef(({
  variant = 'elevated',
  children,
  className = '',
  style = {},
  ...props
}, ref) => {
  const surfaceStyle = {
    backgroundColor: '#ffffff',
    borderRadius: variant === 'elevated' ? '8px' : '0px',
    boxShadow: variant === 'elevated' ? '0 1px 3px rgba(0,0,0,0.12)' : 'none',
    ...style
  };

  return (
    <div
      ref={ref}
      style={surfaceStyle}
      className={`md3-surface ${className}`}
      {...props}
    >
      {children}
    </div>
  );
});

MD3Surface.displayName = 'MD3Surface';

// Progress Component
export const MD3Progress = React.forwardRef(({
  variant = 'linear',
  value,
  size = 'medium',
  className = '',
  style = {},
  ...props
}, ref) => {
  if (variant === 'circular') {
    const circularStyle = {
      width: size === 'small' ? '24px' : size === 'large' ? '48px' : '32px',
      height: size === 'small' ? '24px' : size === 'large' ? '48px' : '32px',
      border: '3px solid #e7e0ec',
      borderTopColor: '#6750a4',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite',
      ...style
    };

    return (
      <div
        ref={ref}
        style={circularStyle}
        className={`md3-progress-circular ${className}`}
        {...props}
      />
    );
  }

  const linearStyle = {
    width: '100%',
    height: '4px',
    backgroundColor: '#e7e0ec',
    borderRadius: '2px',
    overflow: 'hidden',
    ...style
  };

  const progressStyle = {
    height: '100%',
    backgroundColor: '#6750a4',
    width: value ? `${value}%` : '100%',
    animation: value ? 'none' : 'progress-indeterminate 2s linear infinite',
    transition: 'width 0.3s ease'
  };

  return (
    <div
      ref={ref}
      style={linearStyle}
      className={`md3-progress-linear ${className}`}
      {...props}
    >
      <div style={progressStyle} />
    </div>
  );
});

MD3Progress.displayName = 'MD3Progress';

// Floating Action Button Component
export const MD3FloatingActionButton = React.forwardRef(({
  icon,
  size = 'medium',
  disabled = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const fabStyle = {
    width: size === 'small' ? '40px' : size === 'large' ? '64px' : '56px',
    height: size === 'small' ? '40px' : size === 'large' ? '64px' : '56px',
    borderRadius: '50%',
    backgroundColor: '#6750a4',
    color: '#ffffff',
    border: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: size === 'small' ? '16px' : size === 'large' ? '24px' : '20px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    transition: 'all 0.2s ease',
    opacity: disabled ? 0.6 : 1,
    ...style
  };

  return (
    <button
      ref={ref}
      style={fabStyle}
      className={`md3-fab ${className}`}
      disabled={disabled}
      {...props}
    >
      {icon}
    </button>
  );
});

MD3FloatingActionButton.displayName = 'MD3FloatingActionButton';

// CircularProgress alias for backward compatibility
export const CircularProgress = React.forwardRef((props, ref) => {
  return <MD3Progress ref={ref} variant="circular" {...props} />;
});

CircularProgress.displayName = 'CircularProgress';

// useThemeColors hook for backward compatibility
export const useThemeColors = () => {
  return {
    primary: '#6750a4',
    secondary: '#625b71',
    tertiary: '#7d5260',
    surface: '#ffffff',
    background: '#fffbfe',
    error: '#ba1a1a',
    onPrimary: '#ffffff',
    onSecondary: '#ffffff',
    onTertiary: '#ffffff',
    onSurface: '#1c1b1f',
    onBackground: '#1c1b1f',
    onError: '#ffffff'
  };
};

// MD3SortMenu Component
export const MD3SortMenu = React.forwardRef(({
  options = [],
  value,
  onChange,
  label = 'Sort by',
  className = '',
  style = {},
  ...props
}, ref) => {
  const [isOpen, setIsOpen] = useState(false);

  const menuStyle = {
    position: 'relative',
    display: 'inline-block',
    ...style
  };

  const buttonStyle = {
    padding: '8px 16px',
    borderRadius: '8px',
    border: '1px solid #79747e',
    backgroundColor: '#ffffff',
    color: '#1c1b1f',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'all 0.2s ease'
  };

  const dropdownStyle = {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    border: '1px solid #79747e',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    zIndex: 1000,
    marginTop: '4px',
    maxHeight: '200px',
    overflowY: 'auto'
  };

  const optionStyle = {
    padding: '12px 16px',
    cursor: 'pointer',
    fontSize: '14px',
    borderBottom: '1px solid #e7e0ec',
    transition: 'background-color 0.2s ease'
  };

  const selectedOption = options.find(opt => opt.value === value);

  return (
    <div
      ref={ref}
      style={menuStyle}
      className={`md3-sort-menu ${className}`}
      {...props}
    >
      <button
        style={buttonStyle}
        onClick={() => setIsOpen(!isOpen)}
        onBlur={() => setTimeout(() => setIsOpen(false), 150)}
      >
        <span>{selectedOption?.label || label}</span>
        <span style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s ease' }}>▼</span>
      </button>
      
      {isOpen && (
        <div style={dropdownStyle}>
          {options.map((option, index) => (
            <div
              key={option.value}
              style={{
                ...optionStyle,
                backgroundColor: option.value === value ? '#e7e0ec' : 'transparent',
                borderBottom: index === options.length - 1 ? 'none' : '1px solid #e7e0ec'
              }}
              onClick={() => {
                onChange(option.value);
                setIsOpen(false);
              }}
              onMouseEnter={(e) => {
                if (option.value !== value) {
                  e.target.style.backgroundColor = '#f5f5f5';
                }
              }}
              onMouseLeave={(e) => {
                if (option.value !== value) {
                  e.target.style.backgroundColor = 'transparent';
                }
              }}
            >
              {option.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
});

MD3SortMenu.displayName = 'MD3SortMenu';

// MD3ChipGroup Component
export const MD3ChipGroup = React.forwardRef(({
  chips = [],
  selectedChips = [],
  onSelectionChange,
  multiSelect = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const groupStyle = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '8px',
    ...style
  };

  const handleChipClick = (chipValue) => {
    if (!onSelectionChange) return;

    if (multiSelect) {
      const newSelection = selectedChips.includes(chipValue)
        ? selectedChips.filter(v => v !== chipValue)
        : [...selectedChips, chipValue];
      onSelectionChange(newSelection);
    } else {
      onSelectionChange(selectedChips.includes(chipValue) ? [] : [chipValue]);
    }
  };

  return (
    <div
      ref={ref}
      style={groupStyle}
      className={`md3-chip-group ${className}`}
      {...props}
    >
      {chips.map((chip, index) => {
        const isSelected = selectedChips.includes(chip.value || chip);
        const chipValue = chip.value || chip;
        const chipLabel = chip.label || chip;
        
        return (
          <MD3Chip
            key={chipValue}
            label={chipLabel}
            onClick={() => handleChipClick(chipValue)}
            style={{
              backgroundColor: isSelected ? '#6750a4' : '#e7e0ec',
              color: isSelected ? '#ffffff' : '#1c1b1f',
              cursor: 'pointer'
            }}
          />
        );
      })}
    </div>
  );
});

MD3ChipGroup.displayName = 'MD3ChipGroup';

// Alias: MD3AssistChip -> MD3Chip (keeps API used elsewhere)
export const MD3AssistChip = MD3Chip;

// MD3Switch Component
export const MD3Switch = React.forwardRef(({
  checked = false,
  onChange,
  disabled = false,
  label,
  className = '',
  style = {},
  ...props
}, ref) => {
  const switchStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '12px',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1,
    ...style
  };

  const trackStyle = {
    width: '52px',
    height: '32px',
    borderRadius: '16px',
    backgroundColor: checked ? '#6750a4' : '#79747e',
    position: 'relative',
    transition: 'background-color 0.2s ease',
    cursor: disabled ? 'not-allowed' : 'pointer'
  };

  const thumbStyle = {
    width: '20px',
    height: '20px',
    borderRadius: '50%',
    backgroundColor: '#ffffff',
    position: 'absolute',
    top: '6px',
    left: checked ? '26px' : '6px',
    transition: 'left 0.2s ease',
    boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
  };

  return (
    <label
      ref={ref}
      style={switchStyle}
      className={`md3-switch ${className}`}
      {...props}
    >
      <div
        style={trackStyle}
        onClick={() => !disabled && onChange && onChange(!checked)}
      >
        <div style={thumbStyle} />
      </div>
      {label && <span style={{ fontSize: '14px', color: '#1c1b1f' }}>{label}</span>}
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange && onChange(e.target.checked)}
        disabled={disabled}
        style={{ display: 'none' }}
      />
    </label>
  );
});

MD3Switch.displayName = 'MD3Switch';

// MD3DialogActions Component
export const MD3DialogActions = React.forwardRef(({
  children,
  className = '',
  style = {},
  ...props
}, ref) => {
  const actionsStyle = {
    display: 'flex',
    gap: '12px',
    justifyContent: 'flex-end',
    padding: '16px 20px 20px',
    borderTop: '1px solid #e7e0ec',
    ...style
  };

  return (
    <div
      ref={ref}
      style={actionsStyle}
      className={`md3-dialog-actions ${className}`}
      {...props}
    >
      {children}
    </div>
  );
});

MD3DialogActions.displayName = 'MD3DialogActions';

// MD3Menu Component
export const MD3Menu = React.forwardRef(({
  open = false,
  onClose,
  anchorEl,
  children,
  className = '',
  style = {},
  ...props
}, ref) => {
  if (!open) return null;

  const menuStyle = {
    position: 'absolute',
    backgroundColor: '#ffffff',
    border: '1px solid #79747e',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    zIndex: 1000,
    minWidth: '120px',
    ...style
  };

  return (
    <div
      ref={ref}
      style={menuStyle}
      className={`md3-menu ${className}`}
      {...props}
    >
      {children}
    </div>
  );
});

MD3Menu.displayName = 'MD3Menu';

// MD3MenuItem Component
export const MD3MenuItem = React.forwardRef(({
  children,
  onClick,
  disabled = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const itemStyle = {
    padding: '12px 16px',
    cursor: disabled ? 'not-allowed' : 'pointer',
    fontSize: '14px',
    color: disabled ? '#79747e' : '#1c1b1f',
    transition: 'background-color 0.2s ease',
    ...style
  };

  return (
    <div
      ref={ref}
      style={itemStyle}
      className={`md3-menu-item ${className}`}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = '#f5f5f5';
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = 'transparent';
        }
      }}
      {...props}
    >
      {children}
    </div>
  );
});

MD3MenuItem.displayName = 'MD3MenuItem';

// MD3MenuDivider Component
export const MD3MenuDivider = React.forwardRef(({
  className = '',
  style = {},
  ...props
}, ref) => {
  const dividerStyle = {
    height: '1px',
    backgroundColor: '#e7e0ec',
    margin: '4px 0',
    ...style
  };

  return (
    <div
      ref={ref}
      style={dividerStyle}
      className={`md3-menu-divider ${className}`}
      {...props}
    />
  );
});

MD3MenuDivider.displayName = 'MD3MenuDivider';

// MD3BookActionsMenu Component
export const MD3BookActionsMenu = React.forwardRef(({
  book,
  onAction,
  className = '',
  style = {},
  ...props
}, ref) => {
  const actions = [
    { label: 'Read', action: 'read', icon: '📖' },
    { label: 'Edit', action: 'edit', icon: '✏️' },
    { label: 'Delete', action: 'delete', icon: '🗑️' }
  ];

  return (
    <MD3Menu ref={ref} className={className} style={style} {...props}>
      {actions.map((action, index) => (
        <MD3MenuItem
          key={action.action}
          onClick={() => onAction && onAction(action.action, book)}
        >
          <span style={{ marginRight: '8px' }}>{action.icon}</span>
          {action.label}
        </MD3MenuItem>
      ))}
    </MD3Menu>
  );
});

MD3BookActionsMenu.displayName = 'MD3BookActionsMenu';

// MD3BookLibraryFab Component
export const MD3BookLibraryFab = React.forwardRef(({
  onClick,
  className = '',
  style = {},
  ...props
}, ref) => {
  return (
    <MD3FloatingActionButton
      ref={ref}
      icon="➕"
      onClick={onClick}
      className={className}
      style={{
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        backgroundColor: '#6750a4',
        ...style
      }}
      {...props}
    />
  );
});

MD3BookLibraryFab.displayName = 'MD3BookLibraryFab';

// MD3IconButton Component
export const MD3IconButton = React.forwardRef(({
  children,
  size = 'medium',
  variant = 'standard',
  disabled = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const iconButtonStyle = {
    width: size === 'small' ? '32px' : size === 'large' ? '48px' : '40px',
    height: size === 'small' ? '32px' : size === 'large' ? '48px' : '40px',
    borderRadius: '50%',
    border: 'none',
    backgroundColor: variant === 'filled' ? '#6750a4' : 'transparent',
    color: variant === 'filled' ? '#ffffff' : variant === 'error' ? '#ba1a1a' : '#6750a4',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: size === 'small' ? '16px' : size === 'large' ? '24px' : '20px',
    transition: 'all 0.2s ease',
    opacity: disabled ? 0.6 : 1,
    ...style
  };

  return (
    <button
      ref={ref}
      style={iconButtonStyle}
      className={`md3-icon-button ${className}`}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
});

MD3IconButton.displayName = 'MD3IconButton';

// Divider Component (primitive)
export const MD3Divider = React.forwardRef(({ inset = false, className = '', style = {}, ...props }, ref) => {
  return (
    <hr
      ref={ref}
      className={`md3-divider ${className}`}
      style={{
        border: 0,
        height: 1,
        backgroundColor: '#e7e0ec',
        margin: inset ? '8px 16px' : '8px 0',
        ...style
      }}
      {...props}
    />
  );
});
MD3Divider.displayName = 'MD3Divider';

// MD3Select Component
export const MD3Select = React.forwardRef(({
  label,
  value,
  onChange,
  children,
  required = false,
  disabled = false,
  fullWidth = false,
  className = '',
  style = {},
  ...props
}, ref) => {
  const selectStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
    width: fullWidth ? '100%' : 'auto',
    ...style
  };

  const selectInputStyle = {
    padding: '12px 16px',
    borderRadius: '8px',
    border: '1px solid #79747e',
    fontSize: '14px',
    backgroundColor: '#ffffff',
    color: '#1c1b1f',
    outline: 'none',
    transition: 'border-color 0.2s ease',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1
  };

  return (
    <div style={selectStyle} className={`md3-select ${className}`}>
      {label && (
        <label style={{ fontSize: '12px', fontWeight: '500', color: '#49454f' }}>
          {label} {required && <span style={{ color: '#ba1a1a' }}>*</span>}
        </label>
      )}
      <select
        ref={ref}
        value={value}
        onChange={onChange}
        disabled={disabled}
        style={selectInputStyle}
        {...props}
      >
        {children}
      </select>
    </div>
  );
});

// --- Card subcomponents (header + content) ---
export const MD3CardHeader = ({
  title,
  subtitle,
  actions,
  className = '',
  style = {},
  ...props
}) => (
  <div
    className={`md3-card-header ${className}`}
    style={{ marginBottom: 12, ...style }}
    {...props}
  >
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        {title && (
          <h2 className="text-title-medium truncate m-0">{title}</h2>
        )}
        {subtitle && (
          <p className="text-body-small text-on-surface-variant m-0 truncate">
            {subtitle}
          </p>
        )}
      </div>
      {actions && <div className="shrink-0">{actions}</div>}
    </div>
  </div>
);

export const MD3CardContent = ({
  children,
  className = '',
  style = {},
  ...props
}) => (
  <div
    className={`md3-card-content ${className}`}
    style={{ display: 'block', ...style }}
    {...props}
  >
    {children}
  </div>
);

MD3Select.displayName = 'MD3Select';

// --- Tooltip (lightweight) ---
export const MD3Tooltip = ({ label, disabled = false, children, className = '', style = {}, ...props }) => {
  // If you want the simplest behavior, use the native title attribute.
  // Screen readers will read aria-label; sighted users get the browser tooltip.
  if (disabled || !label) {
    return (
      <span className={className} style={style} {...props}>
        {children}
      </span>
    );
  }

  return (
    <span
      className={`md3-tooltip-wrapper ${className}`}
      aria-label={label}
      title={label}
      style={{ display: 'inline-flex', ...style }}
      {...props}
    >
      {children}
    </span>
  );
};

// Import and export the new progress controls
export { default as MD3BookProgressControls } from './MD3BookProgressControls';

// Alias: MD3LinearProgress -> MD3Progress (linear variant)
export const MD3LinearProgress = React.forwardRef((props, ref) => (
  <MD3Progress ref={ref} variant="linear" {...props} />
));
MD3LinearProgress.displayName = 'MD3LinearProgress';


// Add CSS animations
if (typeof document !== 'undefined' && !document.querySelector('#md3-animations')) {
  const style = document.createElement('style');
  style.id = 'md3-animations';
  style.textContent = `
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    @keyframes progress-indeterminate {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(100%); }
    }
  `;
  document.head.appendChild(style);
}