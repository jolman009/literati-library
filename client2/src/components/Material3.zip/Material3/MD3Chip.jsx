// src/components/Material3/MD3Chip.jsx
import React, { memo, forwardRef } from 'react';
import './MD3Chip.css';

const MD3Chip = memo(forwardRef(({
  label,
  variant = 'assist',
  selected = false,
  disabled = false,
  icon,
  avatar,
  onDelete,
  onClick,
  className = '',
  ...props
}, ref) => {
// Remove custom props before passing to DOM
  const {
    multiSelect: _multiSelect,
    value: _value,
    onChange: _onChange,
    label: _label,
    ...domProps
  } = props;

  const classes = [
    'md3-chip-group',
    multiSelect && 'md3-chip-group--multi-select',
    className
  ].filter(Boolean).join(' ');

  const handleChipToggle = (chipValue) => {
    if (!onChange) return;

    if (multiSelect) {
      const newValue = value.includes(chipValue)
        ? value.filter(v => v !== chipValue)
        : [...value, chipValue];
      onChange(newValue);
    } else {
      onChange(chipValue);
    }
  };


 return (
    <div className={classes} {...domProps}>
      {label && (
        <span className="md3-chip-group__label">{label}</span>
      )}
      <div className="md3-chip-group__chips">
        {React.Children.map(children, child => {
          if (React.isValidElement(child)) {
            const isSelected = multiSelect 
              ? value.includes(child.props.value)
              : value === child.props.value;
            
            return React.cloneElement(child, {
              selected: isSelected,
              onClick: () => handleChipToggle(child.props.value)
            });
          }
          return child;
        })}
      </div>
    </div>
  );
}));

MD3Chip.displayName = 'MD3Chip';

// Chip Group Component
export const MD3ChipGroup = memo(({
  chips = [],
  value = [],
  onChange,
  variant = 'filter',
  multiSelect = true,
  label,
  className = ''
}) => {
  const handleChipClick = (chipValue, index) => {
    if (variant === 'filter') {
      if (multiSelect) {
        const newValue = value.includes(chipValue)
          ? value.filter(v => v !== chipValue)
          : [...value, chipValue];
        onChange?.(newValue);
      } else {
        const newValue = value.includes(chipValue) ? [] : [chipValue];
        onChange?.(newValue);
      }
    } else {
      onChange?.(chipValue, index);
    }
  };

  const groupClasses = [
    'md3-chip-group',
    `md3-chip-group--${variant}`,
    className
  ].filter(Boolean).join(' ');

  return (
    <div className={groupClasses}>
      {label && (
        <span className="md3-chip-group__label">
          {label}
        </span>
      )}
      
      <div className="md3-chip-group__container" role="group">
        {chips.map((chip, index) => {
          const isObject = typeof chip === 'object';
          const chipValue = isObject ? chip.value : chip;
          const chipLabel = isObject ? chip.label : chip;
          const chipIcon = isObject ? chip.icon : undefined;
          const chipAvatar = isObject ? chip.avatar : undefined;
          const chipDisabled = isObject ? chip.disabled : false;
          
          const isSelected = variant === 'filter' 
            ? value.includes(chipValue)
            : value === chipValue;

          return (
            <MD3Chip
              key={chipValue || index}
              label={chipLabel}
              variant={variant}
              selected={isSelected}
              disabled={chipDisabled}
              icon={chipIcon}
              avatar={chipAvatar}
              onClick={() => handleChipClick(chipValue, index)}
              onDelete={isObject && chip.onDelete ? chip.onDelete : undefined}
            />
          );
        })}
      </div>
    </div>
  );
});

MD3ChipGroup.displayName = 'MD3ChipGroup';

// Book Genre Chips (specialized component)
export const MD3BookGenreChips = memo(({
  genres = [],
  selectedGenres = [],
  onGenreChange,
  className = ''
}) => {
  const popularGenres = [
    { value: 'fiction', label: 'Fiction', icon: '📚' },
    { value: 'non-fiction', label: 'Non-Fiction', icon: '📖' },
    { value: 'mystery', label: 'Mystery', icon: '🔍' },
    { value: 'romance', label: 'Romance', icon: '💕' },
    { value: 'sci-fi', label: 'Sci-Fi', icon: '🚀' },
    { value: 'fantasy', label: 'Fantasy', icon: '🧙‍♂️' },
    { value: 'biography', label: 'Biography', icon: '👤' },
    { value: 'history', label: 'History', icon: '🏛️' },
    { value: 'self-help', label: 'Self-Help', icon: '💡' },
    { value: 'business', label: 'Business', icon: '💼' }
  ];

  const availableGenres = genres.length > 0 ? genres : popularGenres;

  return (
    <MD3ChipGroup
      chips={availableGenres}
      value={selectedGenres}
      onChange={onGenreChange}
      variant="filter"
      multiSelect={true}
      label="Filter by Genre"
      className={`md3-book-genre-chips ${className}`}
    />
  );
});

MD3BookGenreChips.displayName = 'MD3BookGenreChips';

export default MD3ChipGroup;